var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
export class Exchange {
    constructor(symbol, lP, volume, pCp) {
        this.symbol = symbol;
        this.lastPrice = lP;
        this.volume = volume;
        this.priceChangePercent = pCp;
    }
}
export class Crypto {
    constructor() {
        this.bianceFetch = fetch("https://api2.binance.com/api/v3/ticker/24hr");
    }
    getData() {
        let data = this.bianceFetch
            .then((respond) => {
            console.log(respond.status);
            return respond.json();
        })
            .then((cryptoList) => {
            console.log(cryptoList);
            return cryptoList;
        })
            .catch((error) => {
            console.log("This is error message : ", error);
        });
        return data;
    }
    getMaxPriceChange() {
        return __awaiter(this, void 0, void 0, function* () {
            let cryptoList = yield this.getData();
            let result = {};
            let maxChangePercent = Number(cryptoList[0].priceChangePercent);
            cryptoList.map((cryotoCurrency) => {
                let CurrentPriceChangePercent = Number(cryotoCurrency.priceChangePercent);
                if (CurrentPriceChangePercent > maxChangePercent) {
                    maxChangePercent = CurrentPriceChangePercent;
                    result = {
                        symbol: cryotoCurrency.symbol,
                        ChangePercent: maxChangePercent,
                    };
                }
            });
            // console.log(result);
            return result;
        });
    }
}
