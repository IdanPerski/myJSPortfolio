import { Exchange } from "./Classes.js";
import { addDataToHtmlElement, createElementAndAppend, sortBy, } from "./myFunctions.js";
function getData() {
    return new Promise((resolve, reject) => {
        const xhttp = new XMLHttpRequest();
        xhttp.open("GET", "https://api2.binance.com/api/v3/ticker/24hr");
        xhttp.onload = function () {
            if (xhttp.status == 200) {
                resolve(JSON.parse(xhttp.response));
            }
            else {
                reject(xhttp.status);
            }
        };
        xhttp.send();
    });
}
//create new Exchanges
let data;
function createDataArray() {
    getData()
        .then((value) => {
        console.log(value);
        data = value.map((exchange) => {
            return new Exchange(exchange.symbol, Number(exchange.lastPrice), Number(exchange.volume), Number(exchange.priceChangePercent));
        });
        console.log(data);
        //displying the ExChange
        updatePage(data);
    })
        .catch((error) => {
        console.log(error);
    });
}
window.addEventListener("load", (event) => {
    // initial table state
    createDataArray();
});
function updatePage(data) {
    const tableBody = document.querySelector("#table-body");
    tableBody.innerHTML = "";
    data.map((exchange, i) => {
        createElementAndAppend(tableBody, "tr", "id", `tr-${i}`);
        const tableRow = document.querySelector(`#tr-${i}`);
        tableRow.style.textAlign = "center";
        addDataToHtmlElement(tableRow, "td", "", exchange.symbol);
        addDataToHtmlElement(tableRow, "td", "", exchange.lastPrice);
        addDataToHtmlElement(tableRow, "td", "", exchange.volume);
        addDataToHtmlElement(tableRow, "td", "", exchange.priceChangePercent);
    });
}
//display currency by typing inside the input
const currencyInputName = document.querySelector("#currency-name");
currencyInputName.addEventListener("input", () => {
    let filterdExchange = data.filter((exchange) => {
        const upperCaseValue = currencyInputName.value.toUpperCase();
        return exchange.symbol.includes(upperCaseValue);
    });
    updatePage(filterdExchange);
});
//scope for price search
function priceSearch() {
    const priceSearchBtn = document.querySelector("#price-search-button");
    const maxPrice = document.querySelector("#max-price");
    const minPrice = document.querySelector("#min-price");
    maxPrice.addEventListener("input", () => {
        rangeValidation(priceSearchBtn, minPrice, maxPrice);
    });
    minPrice.addEventListener("input", () => {
        rangeValidation(priceSearchBtn, minPrice, maxPrice);
    });
    priceSearchBtn.addEventListener("click", () => {
        updatePage(rangeFilter(priceSearchBtn, minPrice, maxPrice));
    });
}
priceSearch();
//scope for volume
function vloumeScope() {
    const vloumeSearchBtn = document.querySelector("#volume-search-button");
    const maxVolumeInput = document.querySelector("#max-volume");
    const minVolumeInput = document.querySelector("#min-volume");
    maxVolumeInput.addEventListener("input", () => {
        rangeValidation(vloumeSearchBtn, minVolumeInput, maxVolumeInput);
    });
    vloumeSearchBtn.addEventListener("input", () => {
        rangeValidation(vloumeSearchBtn, minVolumeInput, maxVolumeInput);
    });
    vloumeSearchBtn.addEventListener("click", () => {
        updatePage(rangeFilter(vloumeSearchBtn, minVolumeInput, maxVolumeInput));
    });
}
vloumeScope();
//global scope functions
function rangeValidation(btn, min, max) {
    const minValue = Number(min.value);
    const maxValue = Number(max.value);
    switch (minValue > maxValue) {
        case true:
            btn.innerText = "Disabled";
            btn.disabled = true;
            break;
        case false:
            btn.innerHTML = "Search";
            btn.disabled = false;
            break;
        default:
            btn.innerHTML = "Search";
            btn.disabled = false;
            break;
    }
}
function rangeFilter(btn, min, max) {
    const minValue = Number(min.value);
    const maxValue = Number(max.value);
    const fileteredExchangePrice = data.filter((exchangePrice) => {
        let lastPrice = Number(exchangePrice.lastPrice);
        let filterResult;
        if (lastPrice >= minValue && lastPrice <= maxValue) {
            // const tableBody = document.querySelector('#table-body')!.innerHTML='';
            filterResult = exchangePrice;
        }
        return filterResult;
    });
    return fileteredExchangePrice;
}
// top ten by volume
function sortTop10() {
    const top10Btn = document.querySelector("#top-10-button");
    top10Btn.addEventListener("click", () => {
        const sortData = data.sort((a, b) => {
            return b.volume - a.volume;
        });
        updatePage(sortData.slice(0, 10));
    });
}
sortTop10();
/* sortData scope */
function sortData() {
    const sortBtn = document.querySelector("#sort-button");
    sortBtn.addEventListener("click", () => {
        const selectOption = document.querySelector("#sort-by");
        const sortAscending = document.querySelector("#sort-ascending");
        function sortSelection() {
            if (selectOption.value === "symbol") {
                return sortBy(data, "symbol").reverse();
            }
            else {
                return sortBy(data, selectOption.value);
            }
        }
        if (sortAscending.checked == true) {
            updatePage(sortSelection().reverse());
        }
        else {
            updatePage(sortSelection());
        }
    });
}
sortData();
