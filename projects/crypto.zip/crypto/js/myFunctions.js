export function createElementAndAppend(parentElement, tag, attribute, attValue) {
    const childElement = document.createElement(tag);
    childElement.setAttribute(attribute, attValue);
    return parentElement.appendChild(childElement);
}
export function addDataToHtmlElement(element, AddTag, text = "", data) {
    element.innerHTML += `<${AddTag}>${text} ${data}</${AddTag}>`;
}
export function sortBy(array, objKey) {
    const sortedArray = array.sort((a, b) => {
        if (a[objKey] > b[objKey]) {
            return -1;
        }
        if (a[objKey] < b[objKey]) {
            return 1;
        }
        return 0;
    });
    return sortedArray;
}
