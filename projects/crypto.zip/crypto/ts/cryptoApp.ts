import { Exchange } from "./Classes.js";
import {
  addDataToHtmlElement,
  createElementAndAppend,
  sortBy,
} from "./myFunctions.js";

function getData(): Promise<any> {
  return new Promise((resolve, reject) => {
    const xhttp = new XMLHttpRequest();
    xhttp.open("GET", "https://api2.binance.com/api/v3/ticker/24hr");
    xhttp.onload = function () {
      if (xhttp.status == 200) {
        resolve(JSON.parse(xhttp.response));
      } else {
        reject(xhttp.status);
      }
    };
    xhttp.send();
  });
}

//create new Exchanges
let data: Exchange[];
function createDataArray() {
  getData()
    .then((value: any) => {
      console.log(value);
      data = value.map((exchange: any) => {
        return new Exchange(
          exchange.symbol,
          Number(exchange.lastPrice),
          Number(exchange.volume),
          Number(exchange.priceChangePercent),
        );
      });

      console.log(data);
      //displying the ExChange
      updatePage(data);
    })
    .catch((error) => {
      console.log(error);
    });
}

window.addEventListener("load", (event) => {
  // initial table state
  createDataArray();
});

function updatePage(data: Exchange[]): void {
  const tableBody = document.querySelector("#table-body") as HTMLElement;
  tableBody.innerHTML = "";
  data.map((exchange: Exchange, i: number) => {
    createElementAndAppend(tableBody, "tr", "id", `tr-${i}`) as HTMLElement;
    const tableRow = document.querySelector(`#tr-${i}`) as HTMLElement;
    tableRow.style.textAlign = "center";
    addDataToHtmlElement(tableRow, "td", "", exchange.symbol);
    addDataToHtmlElement(tableRow, "td", "", exchange.lastPrice);
    addDataToHtmlElement(tableRow, "td", "", exchange.volume);
    addDataToHtmlElement(tableRow, "td", "", exchange.priceChangePercent);
  });
}

//display currency by typing inside the input

const currencyInputName = document.querySelector(
  "#currency-name",
) as HTMLInputElement;

currencyInputName.addEventListener("input", () => {
  let filterdExchange: Exchange[] = data.filter((exchange: Exchange) => {
    const upperCaseValue: string = currencyInputName.value.toUpperCase();
    return exchange.symbol.includes(upperCaseValue);
  });
  updatePage(filterdExchange);
});

//scope for price search
function priceSearch() {
  const priceSearchBtn = document.querySelector(
    "#price-search-button",
  ) as HTMLButtonElement;
  const maxPrice = document.querySelector("#max-price") as HTMLInputElement;
  const minPrice = document.querySelector("#min-price") as HTMLInputElement;
  maxPrice.addEventListener("input", () => {
    rangeValidation(priceSearchBtn, minPrice, maxPrice);
  });
  minPrice.addEventListener("input", () => {
    rangeValidation(priceSearchBtn, minPrice, maxPrice);
  });
  priceSearchBtn.addEventListener("click", () => {
    updatePage(rangeFilter(priceSearchBtn, minPrice, maxPrice));
  });
}

priceSearch();

//scope for volume

function vloumeScope() {
  const vloumeSearchBtn = document.querySelector(
    "#volume-search-button",
  ) as HTMLButtonElement;
  const maxVolumeInput = document.querySelector(
    "#max-volume",
  ) as HTMLInputElement;
  const minVolumeInput = document.querySelector(
    "#min-volume",
  ) as HTMLInputElement;
  maxVolumeInput.addEventListener("input", () => {
    rangeValidation(vloumeSearchBtn, minVolumeInput, maxVolumeInput);
  });
  vloumeSearchBtn.addEventListener("input", () => {
    rangeValidation(vloumeSearchBtn, minVolumeInput, maxVolumeInput);
  });

  vloumeSearchBtn.addEventListener("click", () => {
    updatePage(rangeFilter(vloumeSearchBtn, minVolumeInput, maxVolumeInput));
  });
}
vloumeScope();

//global scope functions
function rangeValidation(
  btn: HTMLButtonElement,
  min: HTMLInputElement,
  max: HTMLInputElement,
) {
  const minValue: number = Number(min.value);
  const maxValue: number = Number(max.value);

  switch (minValue > maxValue) {
    case true:
      btn.innerText = "Disabled";
      btn.disabled = true;
      break;
    case false:
      btn.innerHTML = "Search";
      btn.disabled = false;
      break;

    default:
      btn.innerHTML = "Search";
      btn.disabled = false;
      break;
  }
}

function rangeFilter(
  btn: HTMLButtonElement,
  min: HTMLInputElement,
  max: HTMLInputElement,
) {
  const minValue: number = Number(min.value);
  const maxValue: number = Number(max.value);
  const fileteredExchangePrice = data.filter((exchangePrice: Exchange) => {
    let lastPrice = Number(exchangePrice.lastPrice);
    let filterResult;
    if (lastPrice >= minValue && lastPrice <= maxValue) {
      // const tableBody = document.querySelector('#table-body')!.innerHTML='';
      filterResult = exchangePrice;
    }
    return filterResult;
  });
  return fileteredExchangePrice;
}

// top ten by volume
function sortTop10(): void {
  const top10Btn = document.querySelector(
    "#top-10-button",
  ) as HTMLButtonElement;
  top10Btn.addEventListener("click", () => {
    const sortData = data.sort((a: any, b: any) => {
      return b.volume - a.volume;
    });

    updatePage(sortData.slice(0, 10));
  });
}

sortTop10();

/* sortData scope */
function sortData() {
  const sortBtn = document.querySelector("#sort-button") as HTMLButtonElement;
  sortBtn.addEventListener("click", () => {
    const selectOption = document.querySelector(
      "#sort-by",
    ) as HTMLSelectElement;
    const sortAscending = document.querySelector(
      "#sort-ascending",
    ) as HTMLInputElement;

    function sortSelection() {
      if (selectOption.value === "symbol") {
        return sortBy(data, "symbol").reverse();
      } else {
        return sortBy(data, selectOption.value);
      }
    }

    if (sortAscending.checked == true) {
      updatePage(sortSelection().reverse());
    } else {
      updatePage(sortSelection());
    }
  });
}
sortData();
