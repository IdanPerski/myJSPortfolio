export class Exchange {
  symbol: string;
  lastPrice: number;
  volume: number;
  priceChangePercent: number;

  constructor(symbol: string, lP: number, volume: number, pCp: number) {
    this.symbol = symbol;
    this.lastPrice = lP;
    this.volume = volume;
    this.priceChangePercent = pCp;
  }
}

export class Crypto {
  bianceFetch: Promise<Response> = fetch(
    "https://api2.binance.com/api/v3/ticker/24hr",
  );
  getData(): any {
    let data: { [key: string]: any } = this.bianceFetch
      .then((respond: Response) => {
        console.log(respond.status);
        return respond.json();
      })
      .then((cryptoList: [string]) => {
        console.log(cryptoList);
        return cryptoList;
      })
      .catch((error: Error) => {
        console.log("This is error message : ", error);
      });
    return data;
  }
  async getMaxPriceChange() {
    let cryptoList: Array<any> = await this.getData();
    let result: object = {};
    let maxChangePercent: number = Number(cryptoList[0].priceChangePercent);
    cryptoList.map((cryotoCurrency: any) => {
      let CurrentPriceChangePercent: number = Number(
        cryotoCurrency.priceChangePercent,
      );
      if (CurrentPriceChangePercent > maxChangePercent) {
        maxChangePercent = CurrentPriceChangePercent;
        result = {
          symbol: cryotoCurrency.symbol,
          ChangePercent: maxChangePercent,
        };
      }
    });
    // console.log(result);

    return result;
  }
}
