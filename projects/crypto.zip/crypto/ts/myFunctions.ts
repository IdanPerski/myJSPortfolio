export function createElementAndAppend(
  parentElement: HTMLElement,
  tag: string,
  attribute: string,
  attValue: string,
): HTMLElement {
  const childElement = document.createElement(tag);
  childElement.setAttribute(attribute, attValue);
  return parentElement.appendChild(childElement);
}

export function addDataToHtmlElement(
  element: HTMLElement,
  AddTag: string,
  text: string = "",
  data: any,
): void {
  element.innerHTML += `<${AddTag}>${text} ${data}</${AddTag}>`;
}

export function sortBy(array: any, objKey: any) {
  const sortedArray = array.sort((a: string, b: string) => {
    if (a[objKey] > b[objKey]) {
      return -1;
    }
    if (a[objKey] < b[objKey]) {
      return 1;
    }
    return 0;
  });

  return sortedArray;
}
