"use strict";

function Movie(name, lengthMinutes, category, price) {
  this.name = name;
  this.lengthMinutes = lengthMinutes;
  this.category = category;
  this.price = price;

  this.html = document.createElement("div");
  this.html.innerText = `Name: ${this.name}
   Category: ${this.category}
    Minutes: ${this.lengthMinutes}
     Price: ${this.price}`;

  this.html.className = "movieDiv";

  this.image = document.createElement("img");
  this.html.appendChild(this.image);
  this.html.classList.add("rounded");
  this.html.classList.add("border");
  this.html.classList.add("border-dark");
  this.image.setAttribute(
    "src",
    `https://picsum.photos/200/200?random=${Math.floor(Math.random() * 100)}`,
  );

  this.deleteBtn = document.createElement("button");
  this.deleteBtn.setAttribute("class", "delete-button");
  this.deleteBtn.innerText = "Dlelete";
  let randomColor = `#${Math.floor(Math.random() * 10000000).toString(16)}`;
  this.deleteBtn.style.backgroundColor = randomColor;

  this.html.appendChild(this.deleteBtn);

  this.id = this.name + this.lengthMinutes;
  this.deleteBtn.addEventListener("click", () => {
    movies = movies.filter((movie) => {
      return movie.id != this.id;
    });
    arvhiveArray.push(this);
    console.log(arvhiveArray);
    return displayMovies(movies);
  });
}

let arvhiveArray = [];

let addBlock = document.createElement("div");
addBlock.className = "movieDiv";
addBlock.fontSize = "4rem";
addBlock.innerText = "+";

function poninterForElemnet(element) {
  if (element.innerText === "+") element.style.cursor = "pointer";
}
poninterForElemnet(addBlock);

let movies = [];
movies.push(new Movie("luck", 100, "comedy", 32));
movies.push(new Movie("heart", 85, "drama", 40));
movies.push(new Movie("unholy", 100, "horror", 32));
movies.push(new Movie("blonde", 135, "drama", 25));
movies.push(new Movie("me time", 92, "comedy", 30));
movies.push(new Movie("choose or die", 118, "horror", 36));
movies.push(new Movie("red note", 110, "comedy", 40));

const moviesContainer = document.querySelector("#moviesContainer");
const form = document.querySelector("#formContainer");

function displayMovies(array) {
  moviesContainer.innerHTML = "";
  array.map((movie) => {
    return moviesContainer.appendChild(movie.html);
  });
  moviesContainer.appendChild(addBlock);
}

// initial state
displayMovies(movies);

const searchInput = document.querySelector("#search-input");

function searchMovie() {
  let filteredArray = movies.filter((movie) => {
    return movie.name.includes(searchInput.value);
  });
  return displayMovies(filteredArray);
}

searchInput.addEventListener("input", searchMovie);

addBlock.addEventListener("click", () => {
  form.style.display = "block";
});

const movieName = document.querySelector("#movieName");
const movieLength = document.querySelector("#movieLength");
const category = document.querySelector("#category");
const moviePrice = document.querySelector("#moviePrice");
const formBtn = document.querySelector("#formBtn");
const addForm = document.querySelector("#addForm");

formBtn.addEventListener("click", () => {
  let myMovie = new Movie(
    movieName.value,
    movieLength.value,
    category.value,
    moviePrice.value,
  );
  movies.push(myMovie);
  form.style.display = "none";
  addForm.reset();
  displayMovies(movies);
});

function filterBtn() {
  const filterLenBtn = document.querySelector("#filterLenBtn");
  const fromLen = document.querySelector("#fromLen");
  const toLen = document.querySelector("#toLen");

  filterLenBtn.addEventListener("click", () => {
    const filteredArray = movies.filter((movie) => {
      if (
        fromLen.value <= movie.lengthMinutes &&
        toLen.value >= movie.lengthMinutes
      ) {
        return movie;
      }
    });
    displayMovies(filteredArray);
  });
}
filterBtn();
//delete

function sortMovies() {
  const sortMovies = document.querySelector("#sortMovies");
  const sortBySelect = document.querySelector("#sortBySelect");

  sortBySelect.addEventListener("change", () => {
    switch (sortBySelect.value) {
      case "category":
        displayMovies(sortBy(movies, "category"));
        break;
      case "length":
        displayMovies(sortBy(movies, "lengthMinutes"));
        break;
      case "name":
        displayMovies(sortBy(movies, "name"));
        break;
      case "priceLow2High":
        displayMovies(sortBy(movies, "price").reverse());
        break;
      case "PriceHigh2Low":
        displayMovies(sortBy(movies, "price"));
        break;

      default:
        break;
    }
  });

  function sortBy(array, objKey) {
    array = array.sort((a, b) => {
      if (a[objKey] > b[objKey]) {
        return 1;
      }
      if (a[objKey] < b[objKey]) {
        return -1;
      }

      return 0;
    });
    return array;
  }
}

sortMovies();
