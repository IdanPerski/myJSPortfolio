class SiteMarker {
  constructor(siteName, url) {
    this.name = siteName;
    this.url = url;
    this.html = document.createElement("div");
    this.html.classList.add("siteMarker-style");
    this.html.innerHTML = `
      <li><h4>${this.name}</h4></li> 
      <li>
      Bookmark URL: 
      <a href="${this.url}" target="_blank">${this.url}</a>
      </li>
      <button class="deleteObject">
      <i class="fa-solid fa-trash"></i>
      </button>
    `;
    const deleteBtn = this.html.querySelector(".deleteObject");
    deleteBtn.addEventListener("click", () => {
      this.delete();
    });
  }

  delete() {
    // Remove data from localStorage
    const bookmarks = JSON.parse(localStorage.getItem("bookmarks"));
    const index = bookmarks.findIndex(
      (bookmark) => bookmark.name === this.name && bookmark.url === this.url,
    );
    bookmarks.splice(index, 1);
    localStorage.setItem("bookmarks", JSON.stringify(bookmarks));

    handleDisplayClearBtn();

    // Remove HTML element
    this.html.remove();
  }

  DisplayBookmark(parent) {
    parent.appendChild(this.html);
  }
}

const BookmarksDiv = document.querySelector("#bookmarks");
const displayAllBookmarks = (array) => {
  BookmarksDiv.innerHTML = "";
  array.map((bookmark) => {
    bookmark.DisplayBookmark(BookmarksDiv);
  });
};

let bookmarks = JSON.parse(localStorage.getItem("bookmarks")) || [];
// Convert saved data into array of SiteMarker objects
bookmarks = bookmarks.map(
  (bookmark) => new SiteMarker(bookmark.name, bookmark.url),
);

const clearBtn = document.querySelector("#clearBtn");

function handleDisplayClearBtn() {
  if (bookmarks.length == 0) {
    clearBtn.classList.add("d-none");
  } else {
    clearBtn.classList.remove("d-none");
  }
}
handleDisplayClearBtn();

/* _______Add Button__________ */
const submitBtn = document.querySelector("#submitBtn");
submitBtn.addEventListener("click", (e) => {
  e.preventDefault();
  const siteNameInput = document.querySelector("#siteName");
  const siteUrlInput = document.querySelector("#siteUrl");
  /* Validation */
  const url = urlValidation(siteUrlInput.value);

  const mark = new SiteMarker(siteNameInput.value, url);
  bookmarks.push(mark);

  displayAllBookmarks(bookmarks);
  clearBtn.classList.remove("d-none");
  localStorage.setItem("bookmarks", JSON.stringify(bookmarks));

  siteNameInput.value = "";
  siteUrlInput.value = "";
  clearBtn.classList.remove("d-none");
});

displayAllBookmarks(bookmarks);

//clearing the bookmarks from local storage
clearBtn.addEventListener("click", (e) => {
  e.preventDefault();
  localStorage.clear();
  BookmarksDiv.innerHTML = "";
  bookmarks = [];
  clearBtn.classList.add("d-none");
});

function urlValidation(url) {
  const urlRegex =
    /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i;

  if (!urlRegex.test(url)) {
    alert("Please enter a valid URL.");
    return;
  }

  const httpsRegex = /^https?:\/\//i;
  if (!httpsRegex.test(url)) {
    url = `https://www.${url}`;

    return url;
  }
}
