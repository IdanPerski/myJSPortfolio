export default function Timer(
  initialTime,
  createTimerElements,
  min,
  sec,
  descriptionElement,
) {
  console.log(createTimerElements);
  sec = sec.value;
  min = min.value;

  this.initialTime = initialTime;
  this.descriptionElement = descriptionElement.value;

  let displayTime;
  let timerInterval;
  let timerIsOn;

  if (initialTime == "") {
    initialTime = "00";
  }

  function createButton(element, innerText, setclass, eventFunction) {
    const newElement = document.createElement(element);
    newElement.innerText = innerText;
    newElement.setAttribute("class", setclass);
    newElement.addEventListener("click", eventFunction);
    return newElement;
  }

  function createElementAndAppend(parentElement, tag, attribute, attValue) {
    const childElement = document.createElement(tag);
    childElement.setAttribute(attribute, attValue);
    return parentElement.appendChild(childElement);
  }

  function createDivButtons() {
    const divBtn = createElementAndAppend(
      createTimerElements,
      "div",
      "class",
      "text-center bg-danger",
    );
    const buttons = [
      createButton("button", "Start", "startBtn", startTimer),
      createButton("button", "Stop", "stopBtn", stopTimer),
      createButton("button", "Delete", "deleteBtn", deleteTimer),
    ];
    for (let i = 0; i < buttons.length; i++) {
      divBtn.appendChild(buttons[i]);
    }

    return divBtn;
  }

  function formatSeconds(seconds) {
    if (seconds == "") {
      seconds = "0";
    }
    if (seconds < 10) {
      return `0${seconds}`;
    } else {
      return seconds;
    }
  }

  function showTime() {
    sec = formatSeconds(sec);
  }

  function createTimerContainer() {
    const newTimer = document.createElement("div");
    createTimerElements.appendChild(newTimer);
    newTimer.setAttribute(
      "class",
      "timer-and-buttons w-50 border border-dark m-2",
    );

    showTime();
    displayTime = document.createElement("span");
    displayTime.innerText = min + ":" + sec;
    newTimer.appendChild(displayTime);
    displayTime.classList.add("bg-danger");
    displayTime.classList.add("fs-1");
    createElementAndAppend(
      newTimer,
      "div",
      "class",
      `text-center text-white bg-dark fs-5`,
    ).innerText = descriptionElement.value;
    console.log(descriptionElement.value);
    newTimer.appendChild(createDivButtons());
  }

  function runTimer() {
    if (min == 0 && sec == 0) {
      stopTimer();
      return;
    }
    if (sec == 0) {
      min--;
      sec = 60;
    }
    sec--;
    displayTime.innerText = `${min}:${formatSeconds(sec)}`;
  }

  function stopTimer() {
    timerIsOn = false;
    clearInterval(timerInterval);
  }

  function startTimer() {
    if (timerIsOn) return;
    timerIsOn = true;
    timerInterval = setInterval(runTimer, 1000);
  }

  this.createTimer = function () {
    createTimerContainer();
  };

  function deleteTimer() {
    this.parentNode.parentNode.remove();
  }
}
