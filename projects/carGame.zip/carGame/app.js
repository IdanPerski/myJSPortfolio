function Car(fileSrc, className) {
  this.html = document.createElement("img");
  this.html.src = fileSrc;
  this.html.className = className;

  this.direction = "ArrowRight";
  this.locationColumn = 1;
  this.locationRow = 1;

  // Method to rotate the car based on the pressed key
  this.rotate = function (pressedKey) {
    if (pressedKey == "ArrowDown") {
      this.html.style.transform = "rotate(180deg)";
    }
    if (pressedKey == "ArrowUp") {
      this.html.style.transform = "rotate(0deg)";
    }
    if (pressedKey == "ArrowLeft") {
      this.html.style.transform = "rotate(-90deg)";
    }
    if (pressedKey == "ArrowRight") {
      this.html.style.transform = "rotate(90deg)";
    }

    this.direction = pressedKey;
  };
  // Method to move the car based on the pressed key
  this.move = function (pressedKey) {
    if (pressedKey == "ArrowDown") {
      if (this.locationRow < 10) {
        this.locationRow++;
        this.html.style.gridRow = this.locationRow;
      }
    }
    if (pressedKey == "ArrowUp") {
      if (this.locationRow > 0) {
        this.locationRow--;
        this.html.style.gridRow = this.locationRow;
      }
    }
    if (pressedKey == "ArrowLeft") {
      if (this.locationColumn > 0) {
        this.locationColumn--;
        this.html.style.gridColumn = this.locationColumn;
      }
    }
    if (pressedKey == "ArrowRight") {
      if (this.locationColumn < 10) {
        this.locationColumn++;
        this.html.style.gridColumn = this.locationColumn;
      }
    }
    // Check if the car catches the target or hits a bomb
    carCatchTarget();
    carHitBomb();
  };
}
function Target(fileSrc, className) {
  this.html = document.createElement("img");
  this.html.src = fileSrc;
  this.html.className = className;
  const targetObj = this.html;

  // Set the initial location of the target randomly
  this.locationColumn = Math.floor(Math.random() * 10) + 1;
  this.locationRow = Math.floor(Math.random() * 10) + 1;

  // Method to add the target to the play area at its current location
  this.addNewTarget = function () {
    targetObj.style.gridColumn = this.locationColumn;
    targetObj.style.gridRow = this.locationRow;
  };
}

// Constructor function for creating bombs
function Bomb(fileSrc, className) {
  this.html = document.createElement("img");
  this.locationRow = Math.floor(Math.random() * 10) + 1;
  this.locationColumn = Math.floor(Math.random() * 10) + 1;
  this.html.src = fileSrc;
  this.html.className = className;
  this.html.style.gridColumn = this.locationColumn;
  this.html.style.gridRow = this.locationRow;

  this.addBomb = function () {
    playGround.appendChild(this.html);
  };
  // Method to create the specified number of bombs
  this.createBombs = function (numberOfBombs) {
    console.log(numberOfBombs);
    for (let i = 0; i < numberOfBombs; i++) {
      bombs[i] = new Bomb(fileSrc, className);
      bombs[i].addBomb();
    }
  };
}

const playGround = document.querySelector(".parent");
const myCar = new Car("./images/car2.png", "car");
const target = new Target("./images/target.png", "target");

const bombs = [new Bomb("./images/bomb.png", "bomb")];
let bombsCount = 1;

const displayScore = document.createElement("div");
const container = document.querySelector(".container");

function startGame() {
  scoreBoard();
  // Add the car and target elements to the play area
  playGround.appendChild(myCar.html);
  playGround.appendChild(target.html);

  // Set the initial location of the target randomly and add it to the play area
  target.addNewTarget();
  carCatchTarget();
}

function handeleKey(event) {
  if (myCar.direction == event.key) {
    myCar.move(event.key);
  } else {
    myCar.rotate(event.key);
  }
}

let score = 0;

document.addEventListener("keydown", handeleKey);
document.addEventListener("DOMContentLoaded", startGame);

function carCatchTarget() {
  if (
    myCar.locationColumn == target.locationColumn &&
    myCar.locationRow == target.locationRow
  ) {
    removeAllBombs();
    target.locationRow = Math.floor(Math.random() * 10) + 1;
    target.locationColumn = Math.floor(Math.random() * 10) + 1;
    target.addNewTarget();

    // Make sure the car and target do not share the same location
    preventShareLocation(myCar, target);

    // Increase the score and update the score display
    score++;
    displayScore.innerText = `Your Score is : ${score} `;

    // Create a new bomb object and add it to the play area
    bombs[bombs.length - 1].createBombs(bombsCount++);
    bombs.forEach((bomb) => {
      console.log(bomb);
      preventShareLocation(myCar, bomb);
      preventShareLocation(target, bomb);
    });
  }
}
//display the score
function scoreBoard() {
  container.appendChild(displayScore);
  displayScore.classList.add("score");
  displayScore.innerText = `Your Score is : ${score} `;
}

//   remove all bombs from the play area
const removeAllBombs = () => {
  const playgroundElemntsArray = Array.from(playGround.children);
  playgroundElemntsArray.forEach((element) => {
    element.src.includes("bomb") ? element.remove() : null;
  });
};

// make sure two elements do not share the same location
const preventShareLocation = (element1, element2) => {
  while (
    element1.locationColumn === element2.locationColumn &&
    element1.locationRow === element2.locationRow
  ) {
    element2.locationColumn = Math.floor(Math.random() * 10) + 1;
    element2.locationRow = Math.floor(Math.random() * 10) + 1;
  }
};

function carHitBomb() {
  bombs.forEach((bomb) => {
    if (
      myCar.locationColumn === bomb.locationColumn &&
      myCar.locationRow === bomb.locationRow
    ) {
      score = 0;
      displayScore.innerText = `Your Score is : ${score} `;
      console.log("BOOM!");
      const modal = document.querySelector("#modal");
      modal.classList.add("show");
      modal.classList.add("opacity-75");
      modal.classList.add("bg-dark");
      modal.classList.add("d-block");
      setTimeout(() => location.reload(), 5000);
    }
  });
}

const closeBtn = document.querySelector("#closeModalBtn");

closeBtn.addEventListener("click", () => {
  location.reload();
});
